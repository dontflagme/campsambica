<?php
    phpinfo();
    